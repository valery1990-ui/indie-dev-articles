# indie-dev-articles

这是一个独立开发者文章集合项目。

## 自动化上传

本项目已配置好自动化上传到GitHub的设置：

1. Git配置已完成：
   - 用户名：valery1990-ui
   - 邮箱：valery19902021@outlook.com
   - 远程仓库：https://github.com/valery1990-ui/indie-dev-articles.git

2. 使用以下命令上传更新：
```bash
git add .
git commit -m "你的提交信息"
git push
```

## 项目说明

这个仓库用于收集和分享独立开发相关的文章和资源。